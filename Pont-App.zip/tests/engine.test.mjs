import test from 'node:test';
import assert from 'node:assert/strict';
import { readdir, readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { createInitialState, directionConfig, getLevel, makeLesson, normalizeAnswer, gradeAnswer, getCourseStats, completeLevel } from '../src/engine.js';

const fixture = Array.from({ length: 30 }, (_, i) => ({ id: i + 1, pairs: Array.from({ length: 20 }, (_, j) => ({
  ca: `La frase catalana número ${i * 20 + j} és útil.`, pt: `A frase portuguesa número ${i * 20 + j} é útil.`,
})) }));

test('direction validates its input and keeps the locale of the spoken target', () => {
  assert.deepEqual(directionConfig('ca-pt'), { source: 'ca', target: 'pt', lang: 'pt-PT', sourceLang: 'ca-ES' });
  assert.equal(directionConfig('pt-ca').lang, 'ca-ES');
  assert.throws(() => directionConfig('en-pt'), RangeError);
});

function verifyCourse(course) {
  const introduced = new Set();
  for (let level = 1; level <= 300; level++) {
    const detail = getLevel(course, level);
    assert.equal(detail.stage, ((level - 1) % 10) + 1);
    assert.equal(detail.pairs.length, 2);
    detail.pairIds.forEach(id => { assert.ok(!introduced.has(id)); introduced.add(id); });
    const forward = makeLesson(course, level, 'ca-pt');
    const reverse = makeLesson(course, level, 'pt-ca');
    assert.equal(forward.length, 6);
    assert.deepEqual(forward, makeLesson(course, level, 'ca-pt'), 'lesson generation is deterministic');
    for (let i = 0; i < forward.length; i++) {
      const a = forward[i], b = reverse[i];
      assert.equal(a.id, b.id);
      assert.equal(a.type, b.type);
      assert.equal(a.pairId, b.pairId);
      assert.equal(a.source, b.target);
      assert.equal(a.target, b.source);
      if (a.type === 'choose' || a.type === 'meaning') {
        const unitPairs = course.find(unit => unit.id === a.unitId).pairs;
        const from = a.type === 'choose' ? 'pt' : 'ca';
        const to = a.type === 'choose' ? 'ca' : 'pt';
        assert.deepEqual(a.options.map(option => unitPairs.find(pair => pair[from] === option)[to]), b.options, 'distractors must mirror semantic pair identities');
      }
      assert.ok(introduced.has(a.pairId), 'review must never show an unintroduced pair');
      for (const exercise of [a, b]) {
        assert.equal(gradeAnswer(exercise, exercise.answer).correct, true);
        if (exercise.options) {
          assert.ok(exercise.options.includes(exercise.answer));
          assert.ok(exercise.options.length >= 2 && exercise.options.length <= 4);
          assert.equal(new Set(exercise.options.map(normalizeAnswer)).size, exercise.options.length);
          assert.equal(exercise.options.filter(option => gradeAnswer(exercise, option).correct).length, 1, 'exactly one displayed option must grade as correct');
        }
        if (exercise.type === 'order') {
          assert.equal(new Set(exercise.tokens.map(token => token.id)).size, exercise.tokens.length);
          assert.deepEqual(exercise.tokens.map(token => token.text).sort(), exercise.target.split(/\s+/u).sort());
        }
        if (exercise.type === 'cloze') assert.ok(exercise.prompt.includes('___'));
      }
    }
  }
  assert.equal(introduced.size, 600);
}

test('all 300 levels mirror their semantic pairs and exercise modes in both directions', () => verifyCourse(fixture));

test('invalid levels fail clearly', () => {
  for (const level of [0, 301, 1.5, 'bad']) assert.throws(() => getLevel(fixture, level), RangeError);
  assert.throws(() => getLevel([], 1), /needs 20 pairs/u);
});

test('grading tolerates cosmetic changes, flags accents, and rejects wrong or empty meaning', () => {
  const exercise = { target: 'És l’amic de la Júlia.' };
  assert.deepEqual(gradeAnswer(exercise, "  ÉS l'amic de la Júlia!  "), { correct: true, accentOnly: false });
  assert.deepEqual(gradeAnswer(exercise, "Es l'amic de la Julia"), { correct: true, accentOnly: true });
  assert.equal(gradeAnswer(exercise, 'És el pare de la Júlia').correct, false);
  assert.equal(gradeAnswer(exercise, '').correct, false);
  assert.equal(gradeAnswer({ answer: 'casa', target: 'A casa é grande.' }, 'casa').correct, true);
  assert.equal(gradeAnswer({ answer: 'muito bom' }, [{ text: 'muito' }, { text: 'bom' }]).correct, true);
  assert.notEqual(normalizeAnswer('é'), normalizeAnswer('e'));
});

test('gratitude accepts speaker gender without changing obligation agreement', () => {
  for (const [expected, given] of [['Obrigado!', 'Obrigada'], ['Muito obrigada pela ajuda.', 'Muito obrigado pela ajuda.']]) {
    assert.equal(gradeAnswer({ target: expected }, given).correct, true);
  }
  assert.equal(gradeAnswer({ target: 'Ela é obrigada a trabalhar.' }, 'Ela é obrigado a trabalhar.').correct, false);
  assert.equal(gradeAnswer({ type: 'cloze', answer: 'obrigada', target: 'Ela é obrigada a trabalhar.' }, 'obrigado').correct, false);
});

test('explicit sentence alternatives follow the answer language in both directions', () => {
  const course = structuredClone(fixture);
  for (const unit of course) for (const pair of unit.pairs) {
    pair.caAccepted = [pair.ca.replace('útil', 'important')];
    pair.ptAccepted = [pair.pt.replace('útil', 'importante')];
  }
  const types = new Set();
  for (const level of [1, 11, 101, 201]) for (const direction of ['ca-pt', 'pt-ca']) {
    const config = directionConfig(direction);
    for (const exercise of makeLesson(course, level, direction)) {
      types.add(exercise.type);
      if (exercise.type === 'cloze') continue;
      const [unitId, index] = exercise.pairId.split(':').map(Number);
      const pair = course.find(unit => unit.id === unitId).pairs[index];
      const language = exercise.type === 'meaning' ? config.source : config.target;
      assert.ok(exercise.acceptedAnswers.includes(pair[`${language}Accepted`][0]));
      assert.equal(gradeAnswer(exercise, pair[`${language}Accepted`][0]).correct, true);
    }
  }
  assert.deepEqual([...types].sort(), ['choose', 'meaning', 'order', 'type']);
});

test('cloze alternatives replace only the gap, and aliases cannot become competing options', () => {
  const course = structuredClone(fixture);
  for (const unit of course) for (const pair of unit.pairs) {
    pair.caAccepted = [pair.ca.replace('útil', 'important')];
    pair.ptAccepted = [pair.pt.replace('útil', 'importante')];
    pair.cloze = { ca: 6, pt: 6 };
  }
  let checkedGap = false;
  for (let level = 11; level <= 300 && !checkedGap; level++) {
    const exercise = makeLesson(course, level, 'ca-pt').find(item => item.type === 'cloze' && item.answer === 'útil');
    if (!exercise) continue;
    assert.ok(exercise.acceptedAnswers.includes('importante'));
    assert.equal(gradeAnswer(exercise, 'importante').correct, true);
    assert.ok(exercise.acceptedAnswers.every(answer => !answer.includes(' ')), 'full alternative sentences are not cloze answers');
    checkedGap = true;
  }
  assert.ok(checkedGap);
  course[0].pairs[0].ptAccepted = [course[0].pairs[1].pt];
  const exercise = makeLesson(course, 1, 'ca-pt')[0];
  assert.ok(!exercise.options.includes(course[0].pairs[1].pt));
  const reversed = makeLesson(course, 1, 'pt-ca')[0];
  assert.ok(!reversed.options.includes(course[0].pairs[1].ca), 'alias exclusion is mirrored in the reverse direction');
});

test('progress only unlocks sequential passing levels and isolates direction', () => {
  const start = createInitialState();
  assert.equal(completeLevel(start, 'ca-pt', 2, 6, 6, '2026-11-21'), start);
  assert.equal(completeLevel(start, 'ca-pt', 1, 4, 6, '2026-11-21'), start);
  const passed = completeLevel(start, 'ca-pt', 1, 5, 6, '2026-11-21');
  assert.equal(getCourseStats(passed.progress['ca-pt']).nextLevel, 2);
  assert.equal(getCourseStats(passed.progress['pt-ca']).nextLevel, 1);
  assert.equal(passed.xp, 25);
  assert.deepEqual(start, createInitialState(), 'input state must not be mutated');
  assert.throws(() => completeLevel(start, 'ca-pt', 1, 7, 6), RangeError);
});

test('replaying cannot farm XP; score improvements earn only the difference', () => {
  let state = completeLevel(createInitialState(), 'ca-pt', 1, 5, 6, '2026-11-21');
  state = completeLevel(state, 'ca-pt', 1, 5, 6, '2026-11-21');
  assert.equal(state.xp, 25);
  state = completeLevel(state, 'ca-pt', 1, 6, 6, '2026-11-21');
  assert.equal(state.xp, 35);
  state = completeLevel(state, 'ca-pt', 1, 5, 6, '2026-11-21');
  assert.equal(state.xp, 35);
  assert.equal(state.progress['ca-pt'].completed[1].accuracy, 1);
  state = completeLevel(state, 'pt-ca', 1, 6, 6, '2026-11-21');
  assert.equal(state.xp, 70);
});

test('streaks span courses, advance once per civil day, and reset after a gap', () => {
  let state = completeLevel(createInitialState(), 'ca-pt', 1, 6, 6, '2026-11-21');
  assert.equal(state.streak, 1);
  state = completeLevel(state, 'ca-pt', 2, 6, 6, '2026-11-21T23:55:00+01:00');
  assert.equal(state.streak, 1);
  state = completeLevel(state, 'pt-ca', 1, 6, 6, '2026-11-22');
  assert.equal(state.streak, 2);
  state = completeLevel(state, 'pt-ca', 2, 6, 6, '2026-11-24');
  assert.equal(state.streak, 1);
  state = completeLevel(state, 'pt-ca', 2, 6, 6, '2026-11-23');
  assert.equal(state.lastStudyDate, '2026-11-24');
  assert.throws(() => completeLevel(state, 'ca-pt', 1, 6, 6, '2026-02-30'), RangeError);
});

test('course completion reports 300/300 without inventing a next level', () => {
  let state = createInitialState();
  for (let level = 1; level <= 300; level++) state = completeLevel(state, 'ca-pt', level, 6, 6, '2026-11-21');
  assert.deepEqual(getCourseStats(state.progress['ca-pt']), { completedCount: 300, nextLevel: 301, percent: 100, stars: 900, totalLevels: 300 });
  assert.equal(state.xp, 10500);
});

test('authored course has 600 complete pairs and passes all mirrored lesson invariants', async (t) => {
  const directory = fileURLToPath(new URL('../content/', import.meta.url));
  let files;
  try { files = (await readdir(directory)).filter(name => /^units-\d+-\d+\.json$/u.test(name)); }
  catch { t.skip('Authored course files have not arrived yet'); return; }
  if (files.length !== 3) { t.skip('Authored course files are still in progress'); return; }
  const course = (await Promise.all(files.map(async file => JSON.parse(await readFile(`${directory}/${file}`, 'utf8'))))).flat().sort((a, b) => a.id - b.id);
  assert.equal(course.length, 30);
  assert.deepEqual(course.map(unit => unit.id), Array.from({ length: 30 }, (_, i) => i + 1));
  for (const unit of course) {
    assert.equal(unit.pairs.length, 20);
    for (const lang of ['ca', 'pt']) {
      assert.ok(unit.title[lang] && unit.description[lang] && unit.tip[lang]);
      assert.equal(new Set(unit.pairs.map(pair => normalizeAnswer(pair[lang]))).size, 20, `Unit ${unit.id}: duplicate ${lang} phrases`);
      for (const pair of unit.pairs) assert.equal(typeof pair[lang], 'string');
    }
  }
  verifyCourse(course);
});
