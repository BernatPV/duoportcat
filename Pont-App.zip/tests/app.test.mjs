/** Functional app smoke tests with a small DOM surface, not a browser/layout test. */
import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { readFile, readdir } from 'node:fs/promises';
import * as engine from '../src/engine.js';

const KEY = 'pont.progress.v1';
const contentDir = new URL('../content/', import.meta.url);
const files = (await readdir(contentDir)).filter(name => /^units-\d+-\d+\.json$/u.test(name));
const course = (await Promise.all(files.map(file => readFile(new URL(file, contentDir), 'utf8').then(JSON.parse))))
  .flat().sort((a, b) => a.id - b.id);
assert.equal(course.length, 30);

function decode(value) {
  return value.replace(/&quot;/gu, '"').replace(/&#39;/gu, "'").replace(/&lt;/gu, '<').replace(/&gt;/gu, '>').replace(/&amp;/gu, '&');
}

class Element {
  constructor(document, tag = 'div', attributes = {}) {
    this.document = document;
    this.tagName = tag.toUpperCase();
    this.attributes = attributes;
    this.dataset = Object.fromEntries(Object.entries(attributes).filter(([key]) => key.startsWith('data-'))
      .map(([key, value]) => [key.slice(5).replace(/-([a-z])/gu, (_, letter) => letter.toUpperCase()), value]));
    this.id = attributes.id || '';
    this.disabled = 'disabled' in attributes;
    this.value = attributes.value || '';
    this.files = [];
    this.textContent = '';
    this.innerHTML = '';
    const classes = new Set();
    this.classList = { add: value => classes.add(value), remove: value => classes.delete(value), contains: value => classes.has(value) };
  }
  set innerHTML(value) { this.html = String(value); this.nodes = null; }
  get innerHTML() { return this.html; }
  elements() {
    if (!this.nodes) {
      this.nodes = [...this.html.matchAll(/<(button|input|a|div)\b([^>]*)>/gu)].map(([, tag, raw]) => {
        const attributes = {};
        for (const [, name, double, single, bare] of raw.matchAll(/([\w-]+)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+)))?/gu)) {
          attributes[name] = decode(double ?? single ?? bare ?? '');
        }
        return new Element(this.document, tag, attributes);
      });
    }
    return this.nodes;
  }
  matches(selector) {
    if (selector.startsWith('#')) return this.id === selector.slice(1);
    if (selector.startsWith('[')) {
      const match = /^\[([^=\]]+)(?:="([^"]*)")?\]$/u.exec(selector);
      return !!match && match[1] in this.attributes && (match[2] === undefined || this.attributes[match[1]] === match[2]);
    }
    return this.tagName.toLowerCase() === selector;
  }
  querySelectorAll(selector) { return this.elements().filter(node => selector.split(',').some(part => node.matches(part))); }
  querySelector(selector) { return this.querySelectorAll(selector)[0] || null; }
  closest(selector) { return this.matches(selector) ? this : null; }
  focus() { this.document.activeElement = this; }
  remove() { this.document.overlays = this.document.overlays.filter(node => node !== this); }
  click() { return this.document.dispatch('click', { target: this }); }
}

async function boot({ storage = new Map(), failWrites = false } = {}) {
  const listeners = new Map();
  const document = {
    overlays: [], activeElement: null, documentElement: { lang: '' },
    addEventListener(type, handler) { listeners.set(type, [...(listeners.get(type) || []), handler]); },
    async dispatch(type, event) { for (const handler of listeners.get(type) || []) await handler({ preventDefault() {}, ...event }); },
    createElement(tag) { return new Element(document, tag); },
    querySelector(selector) {
      if (selector === '#app') return root;
      if (selector === '#toast') return toast;
      return [root, ...document.overlays].flatMap(parent => parent.querySelectorAll(selector))[0] || null;
    },
  };
  document.body = { append(node) { document.overlays.push(node); } };
  const root = new Element(document), toast = new Element(document);
  const errors = [];
  const context = vm.createContext({
    ...engine, document,
    window: { innerWidth: 1280, scrollTo() {}, addEventListener() {} }, navigator: {},
    localStorage: {
      getItem: key => storage.get(key) ?? null,
      setItem: (key, value) => { if (failWrites) throw new Error('Storage unavailable'); storage.set(key, value); },
    },
    fetch: async url => { assert.equal(url, './course.json'); return { ok: true, json: async () => structuredClone(course) }; },
    setTimeout: () => 1, clearTimeout() {}, Blob, URL,
    console: { error: error => errors.push(error), log() {}, warn() {} },
  });
  const source = (await readFile(new URL('../src/app.js', import.meta.url), 'utf8')).replace(/^import[^\n]*\n/u, '');
  await new vm.Script(`(async () => {\n${source}\n})()`, { filename: 'app.js' }).runInContext(context);
  assert.deepEqual(errors, [], 'app boot should not fall into the course-load error screen');
  const find = (action, values = {}) => [root, ...document.overlays].flatMap(parent => parent.elements())
    .find(node => node.dataset.action === action && Object.entries(values).every(([key, value]) => node.dataset[key] === String(value)));
  return {
    root, toast, document, storage, errors,
    stored: () => JSON.parse(storage.get(KEY)),
    find,
    async click(action, values = {}) {
      const node = find(action, values);
      assert.ok(node, `Rendered action ${action} ${JSON.stringify(values)} must exist`);
      assert.equal(node.disabled, false, `Rendered action ${action} must be enabled`);
      await node.click();
      assert.deepEqual(errors, []);
    },
    async input(value) {
      const input = document.querySelector('#answer');
      assert.ok(input, 'Translation input is rendered');
      input.value = value;
      await document.dispatch('input', { target: input });
    },
    async file(value) {
      const input = document.querySelector('#import-file');
      assert.ok(input, 'Settings import input is rendered');
      const text = JSON.stringify(value);
      input.files = [{ size: Buffer.byteLength(text), text: async () => text }];
      await document.dispatch('change', { target: input });
    },
  };
}

async function answerQuestion(app, exercise, correct = true) {
  if (exercise.type === 'order') {
    const remaining = [...exercise.tokens];
    const words = exercise.target.split(/\s+/u);
    if (!correct && words.length > 1) [words[0], words[1]] = [words[1], words[0]];
    for (const word of words) {
      const index = remaining.findIndex(token => token.text === word);
      assert.ok(index >= 0);
      const [token] = remaining.splice(index, 1);
      await app.click('token', { token: token.id });
    }
  } else if (exercise.type === 'type') await app.input(correct ? exercise.answer : 'incorrect answer');
  else {
    const index = exercise.options.findIndex(answer => correct ? answer === exercise.answer : answer !== exercise.answer);
    await app.click('option', { index });
  }
  await app.click('check');
  assert.ok(app.find('next'), 'Checking reveals feedback and the continue action');
  await app.click('next');
}

async function completeLesson(app, direction, level, wrongIndices = []) {
  await app.click('level', { level });
  const questions = engine.makeLesson(course, level, direction);
  for (let index = 0; index < questions.length; index++) await answerQuestion(app, questions[index], !wrongIndices.includes(index));
}

test('actual app boots bilingual onboarding, completes a lesson, reloads, and keeps directions independent', async () => {
  const app = await boot();
  assert.match(app.root.innerHTML, /Vull aprendre portuguès/u);
  assert.match(app.root.innerHTML, /Quero aprender catalão/u);
  await app.click('direction', { direction: 'ca-pt' });
  assert.equal(app.document.documentElement.lang, 'ca');
  assert.equal(app.find('level', { level: 2 }).disabled, true);
  await completeLesson(app, 'ca-pt', 1);
  assert.match(app.root.innerHTML, /6 \/ 6/u);
  assert.equal(app.stored().progress['ca-pt'].completed[1].accuracy, 1);
  assert.equal(app.stored().xp, 35);
  await app.click('finish');
  assert.equal(app.find('level', { level: 2 }).disabled, false);

  const reloaded = await boot({ storage: app.storage });
  assert.equal(reloaded.document.documentElement.lang, 'ca');
  assert.equal(reloaded.find('level', { level: 2 }).disabled, false);
  await reloaded.click('switch');
  await reloaded.click('direction', { direction: 'pt-ca' });
  assert.equal(reloaded.document.documentElement.lang, 'pt');
  assert.equal(reloaded.find('level', { level: 2 }).disabled, true);
  await completeLesson(reloaded, 'pt-ca', 1);
  assert.equal(reloaded.stored().xp, 70);
  assert.equal(Object.keys(reloaded.stored().progress['ca-pt'].completed).length, 1);
  assert.equal(Object.keys(reloaded.stored().progress['pt-ca'].completed).length, 1);
});

test('actual app records failed answers, blocks a failed level, and clears phrases through practice', async () => {
  const app = await boot();
  await app.click('direction', { direction: 'ca-pt' });
  await completeLesson(app, 'ca-pt', 1, [0, 1]);
  assert.match(app.root.innerHTML, /4 \/ 6/u);
  assert.ok(app.find('retry'));
  assert.deepEqual(app.stored().progress['ca-pt'].completed, {});
  assert.equal(app.stored().xp, 0);
  const mistakes = app.stored().progress['ca-pt'].mistakes;
  assert.equal(mistakes.length, 2);
  await app.click('finish');
  assert.equal(app.find('level', { level: 2 }).disabled, true);
  await app.click('nav', { page: 'practice' });
  await app.click('practice');
  for (const [index, id] of mistakes.entries()) {
    const [unit, pairIndex] = id.split(':').map(Number);
    const pair = course[unit - 1].pairs[pairIndex];
    const target = pair.pt;
    await answerQuestion(app, { type: 'order', target, tokens: target.split(/\s+/u).map((text, tokenIndex) => ({ id: `p${index}-${tokenIndex}`, text })) });
  }
  assert.match(app.root.innerHTML, /Pràctica completada/u);
  assert.deepEqual(app.stored().progress['ca-pt'].mistakes, []);
  assert.deepEqual(app.stored().progress['ca-pt'].completed, {});
  assert.equal(app.stored().xp, 0);
});

test('actual app accepts typed translations through its input handler in later lessons', async () => {
  let state = engine.createInitialState();
  state.direction = 'ca-pt';
  for (let level = 1; level <= 10; level++) state = engine.completeLevel(state, 'ca-pt', level, 6, 6, '2026-11-21');
  const app = await boot({ storage: new Map([[KEY, JSON.stringify(state)]]) });
  assert.ok(engine.makeLesson(course, 11, 'ca-pt').some(exercise => exercise.type === 'type'));
  await completeLesson(app, 'ca-pt', 11);
  assert.equal(app.stored().progress['ca-pt'].completed[11].accuracy, 1);
  assert.equal(app.stored().xp, 385);
});

test('actual app imports only after confirmation and rejects malformed or nonsequential backups', async () => {
  const app = await boot();
  await app.click('direction', { direction: 'ca-pt' });
  await app.click('nav', { page: 'settings' });
  let backup = engine.createInitialState();
  backup.direction = 'ca-pt';
  backup = engine.completeLevel(backup, 'ca-pt', 1, 6, 6, '2026-11-21');
  await app.file(backup);
  assert.equal(app.stored().xp, 0, 'previewing an import must not replace progress');
  assert.equal(app.document.overlays.length, 1);
  await app.click('confirm-import');
  assert.equal(app.stored().xp, 35);
  assert.equal(app.document.overlays.length, 0);

  const before = app.storage.get(KEY);
  const invalid = structuredClone(backup);
  invalid.progress['ca-pt'].completed[2] = invalid.progress['ca-pt'].completed[1];
  delete invalid.progress['ca-pt'].completed[1];
  await app.file(invalid);
  assert.equal(app.document.overlays.length, 0);
  assert.equal(app.storage.get(KEY), before);
  assert.match(app.toast.textContent, /no és vàlida/u);
  await app.file({ version: 999 });
  assert.equal(app.storage.get(KEY), before);
});

test('actual app reports unavailable storage instead of claiming an imported backup was saved', async () => {
  const app = await boot({ failWrites: true });
  await app.click('direction', { direction: 'ca-pt' });
  await app.click('nav', { page: 'settings' });
  const backup = engine.createInitialState();
  backup.direction = 'ca-pt';
  await app.file(backup);
  await app.click('confirm-import');
  assert.match(app.toast.textContent, /no permet desar/u);
  assert.equal(app.storage.has(KEY), false);
});
