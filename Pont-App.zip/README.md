# Pont

Pont is a learning app for **Portuguese from Catalan** and **Catalan from Portuguese**. Choose a direction when you first open the app. The interface uses your source language, and the same paired course content and exercise sequence are mirrored when you switch directions.

The course uses standard Catalan and **European Portuguese**. It contains **300 levels across 30 units**, built from **600 original bilingual sentence pairs**. Topics progress from greetings and everyday vocabulary to longer sentences, complex grammar, and expressing opinions.

## Learning experience

- Each level has six exercises: two introduce new sentence pairs and four provide review. The first level repeats its new material because no earlier material is available yet.
- Four exercise types cover choosing a translation, identifying meaning, ordering words into a sentence, and typing a translation. Early levels offer more guidance; later levels ask for more typed answers.
- Passing requires at least 80% accuracy: **five correct answers out of six**. Passing unlocks the next level. Completed levels can be replayed.
- Each language direction has its own completed levels and mistake-review list. Switching languages preserves both courses' progress.
- Progress, activity, and preferences are stored locally on the device. Settings provide JSON export and import for backups or moving progress between devices. Import replaces the current saved progress after confirmation; there is no automatic account or cloud synchronization.
- Pronunciation uses the device's speech synthesis when a suitable voice is available. European Portuguese is preferred; another installed Portuguese voice may be used as a fallback. Catalan and Portuguese voices are not available on every device or browser, and audio is not guaranteed offline.

This is an initial original course, not a formally certified curriculum. Native-speaker editorial review of the sentence pairs, acceptable alternatives, and progression is recommended before a public educational release.

## Open the portable app

Extract the download, then open **`dist/Pont-Offline.html`** in a modern desktop browser. This self-contained file includes the app, styling, and all 300 levels; it needs no server, Node.js installation, or internet connection for lessons. If the file opens in an editor, use **Open with** and choose your browser.

Progress depends on that browser allowing local storage for local files. Keep using the same browser and file location, and use **Export progress** in the app's settings to keep a backup. Moving or renaming the HTML file, switching browsers, private browsing, or clearing browser data may make saved progress unavailable. Pronunciation still depends on available device voices and may need a connection.

The HTML file is a portable desktop edition. It is not an Android APK or iPhone app installer; mobile file previews may not run it. For phone installation, use the hosted web-app or native-build routes below. Start with [START-HERE.md](START-HERE.md) for a quick guide.

## Run the web app

Install **Node.js 22 or newer**. The web app, build script, local server, and tests use no external npm dependencies, so `npm install` is unnecessary for this route.

From the project directory:

```sh
node scripts/build.mjs
node scripts/serve.mjs
```

Open **http://localhost:4173** in a browser. Keep the server running while using the local app; press `Ctrl+C` to stop it. The included server listens only on the local computer. It does not provide a phone-accessible hosted URL.

The build combines the course JSON files with the application in `src/` and writes the result to `dist/`, including the self-contained `Pont-Offline.html`. Rebuild after editing source or course data. A supplied prebuilt `dist/` can be served without running the build again.

Run the automated checks with:

```sh
npm test
```

The delivered version passes 17 automated checks, including lesson generation for all 300 levels in both directions, answer grading, unlocking, progress import, and app interactions. The portable HTML also passes syntax and embedded-resource checks. Browser visual testing and native builds could not be completed in this environment. A live hosted URL is not included: source publication was blocked by network name resolution.

Opening `dist/index.html` directly with a `file://` URL is not supported. Use a web server for that edition so modules, course loading, and service workers can work correctly. To open a file directly, use `dist/Pont-Offline.html` instead.

## Install and use offline

Serve the contents of `dist/` from an HTTPS static host, keeping all files together. On Android, open the hosted app in Chrome and choose **Install app** or **Add to Home screen**. On iPhone or iPad, open it in Safari and choose **Share then Add to Home Screen**. The app also provides installation guidance in Settings.

Open the app online first and allow its service worker to cache the application and course. Once caching succeeds, lessons can work offline. Browser storage or cache clearing can remove progress and offline files, so export progress periodically. Speech availability depends on the installed voices and may still require a connection.

Home-screen installation is a web app installation. **This package is not an App Store or Google Play release and does not include signed native binaries.** Native build configuration and preparation scripts are included; see [MOBILE.md](MOBILE.md) for Android and iOS requirements, build instructions, and the current verification limitations.

## Source and course editing

| Location | Purpose |
| --- | --- |
| `src/` | Interface, shared exercise engine, styling, icons, and offline files |
| `dist/Pont-Offline.html` | Self-contained portable app for opening in a desktop browser |
| `content/units-01-10.json` | Beginner course units |
| `content/units-11-20.json` | Intermediate course units |
| `content/units-21-30.json` | Later course units |
| `scripts/build.mjs` | Creates the static web app in `dist/` |
| `scripts/serve.mjs` | Runs the local preview server |
| `tests/` | Course and learning-engine checks |
| `capacitor.config.json` | Shared native app configuration |
| `.github/workflows/mobile-builds.yml` | Optional native test-build workflow |

Every unit has a numeric `id`, bilingual `title`, `description`, and `tip` fields, and 20 `pairs`. Each pair contains `ca` and `pt` strings with equivalent meaning. A unit's ten levels introduce consecutive pairs in groups of two. Keep unit order and pair order stable once people have saved progress, because progress and review refer to those positions.

For valid alternative translations, add optional `caAccepted` or `ptAccepted` arrays to the corresponding pair. The engine accepts the canonical answer and these explicitly authored alternatives. It also handles the Portuguese gratitude variants `obrigado` and `obrigada`, ignores case and cosmetic punctuation, and accepts accent-only differences while showing the accented answer. It does not recognize every possible paraphrase automatically.

Keep both sides of each pair semantically aligned when editing, and check both learning directions. Rebuild and run the tests after changing course data. Native packaging downloads additional dependencies and requires platform tooling; it is separate from the dependency-free web workflow above.
