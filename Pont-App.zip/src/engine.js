/** Shared, deterministic course engine. Both courses use the same semantic pair IDs. */
export const TOTAL_LEVELS = 300;
export const PASS_ACCURACY = 0.8;

export function directionConfig(direction) {
  if (direction === 'ca-pt') return { source: 'ca', target: 'pt', lang: 'pt-PT', sourceLang: 'ca-ES' };
  if (direction === 'pt-ca') return { source: 'pt', target: 'ca', lang: 'ca-ES', sourceLang: 'pt-PT' };
  throw new RangeError('Unknown course direction');
}

export function createInitialState() {
  return {
    version: 1, direction: null,
    progress: { 'ca-pt': { completed: {}, mistakes: [] }, 'pt-ca': { completed: {}, mistakes: [] } },
    xp: 0, streak: 0, lastStudyDate: null, sound: true,
  };
}

export default createInitialState;

export function getLevel(course, levelId) {
  const id = Number(levelId);
  if (!Number.isInteger(id) || id < 1 || id > TOTAL_LEVELS) throw new RangeError('Level must be 1–300');
  const unitId = Math.floor((id - 1) / 10) + 1;
  const unit = course.find(item => Number(item.id) === unitId);
  if (!unit || !Array.isArray(unit.pairs) || unit.pairs.length !== 20) throw new Error(`Unit ${unitId} needs 20 pairs`);
  const stage = ((id - 1) % 10) + 1;
  const start = (stage - 1) * 2;
  return { id, unit, stage, pairs: unit.pairs.slice(start, start + 2), pairIds: [`${unitId}:${start}`, `${unitId}:${start + 1}`] };
}

function hash(value) {
  let h = 2166136261;
  for (const char of String(value)) h = Math.imul(h ^ char.charCodeAt(0), 16777619);
  return h >>> 0;
}

function shuffled(items, seed) {
  const result = [...items];
  let n = hash(seed) || 1;
  for (let i = result.length - 1; i > 0; i--) {
    n ^= n << 13; n ^= n >>> 17; n ^= n << 5;
    const j = (n >>> 0) % (i + 1);
    [result[i], result[j]] = [result[j], result[i]];
  }
  return result;
}

function flatten(course) {
  return [...course].sort((a, b) => a.id - b.id).flatMap(unit => unit.pairs.map((pair, index) => ({
    ...pair, pairId: `${unit.id}:${index}`, unitId: Number(unit.id), pairIndex: index,
  })));
}

function gratitudeVariant(text) {
  // Gratitude agrees with the speaker; do not change agreement elsewhere.
  return String(text).replace(/^((?:muito|muitíssimo)\s+)?obrigad([oa])(?=$|[\s.,!?:;])/iu,
    (_, prefix = '', ending) => `${prefix}obrigad${ending.toLowerCase() === 'o' ? 'a' : 'o'}`);
}

function acceptedSentences(pair, language) {
  const explicit = pair[`${language}Accepted`];
  const sentences = [pair[language], ...(Array.isArray(explicit) ? explicit.filter(value => typeof value === 'string' && value.trim()) : [])];
  return [...new Set(sentences.flatMap(sentence => [sentence, gratitudeVariant(sentence)]))];
}

function answerKey(text) {
  return withoutAccents(normalizeAnswer(text));
}

function choiceOptions(answer, candidates, seed, accepted = []) {
  const found = new Set([answer, ...accepted].map(answerKey));
  const alternatives = [];
  for (const candidate of shuffled(candidates, `${seed}:candidates`)) {
    const normalized = answerKey(candidate);
    if (!normalized || found.has(normalized)) continue;
    found.add(normalized);
    alternatives.push(candidate);
    if (alternatives.length === 3) break;
  }
  return shuffled([answer, ...alternatives], `${seed}:options`);
}

function sentenceOptions(pair, candidates, language, seed) {
  // Filter semantic candidates in both languages, so swapping direction keeps
  // the very same distractor pairs even when one side has an accepted synonym.
  const found = Object.fromEntries(['ca', 'pt'].map(lang => [lang, new Set(acceptedSentences(pair, lang).map(answerKey))]));
  const options = [pair];
  for (const candidate of shuffled(candidates, `${seed}:candidates`)) {
    const keys = Object.fromEntries(['ca', 'pt'].map(lang => [lang, acceptedSentences(candidate, lang).map(answerKey)]));
    if (['ca', 'pt'].some(lang => keys[lang].some(key => found[lang].has(key)))) continue;
    for (const lang of ['ca', 'pt']) keys[lang].forEach(key => found[lang].add(key));
    options.push(candidate);
    if (options.length === 4) break;
  }
  return shuffled(options, `${seed}:options`).map(option => option[language]);
}

function trimToken(token) {
  return token.replace(/^[«»“”„"¡¿(\[]+|[.,!?;:…»«“”"\])]+$/gu, '');
}

/** Six exercises introduce two pairs, then revisit already introduced language. */
export function makeLesson(course, levelId, direction) {
  const config = directionConfig(direction);
  const level = getLevel(course, levelId);
  const all = flatten(course);
  const introduced = all.filter(pair => level.pairIds.includes(pair.pairId));
  const known = all.filter(pair => pair.unitId < level.unit.id || (pair.unitId === level.unit.id && pair.pairIndex < (level.stage - 1) * 2));
  // Prefer this unit, then the most recent previous unit for cumulative retrieval.
  const recent = known.filter(pair => pair.unitId >= level.unit.id - 1);
  const reviewPool = shuffled(recent.length ? recent : known, `review:${level.id}`);
  const selected = [...introduced];
  while (selected.length < 6) {
    const index = selected.length - 2;
    selected.push(reviewPool.length ? reviewPool[index % reviewPool.length] : introduced[index % introduced.length]);
  }
  const modes = level.id <= 10
    ? ['choose', 'choose', 'meaning', 'order', 'order', 'meaning']
    : level.id <= 100
      ? ['choose', 'order', 'meaning', 'cloze', 'order', 'type']
      : level.id <= 200
        ? ['order', 'cloze', 'meaning', 'type', 'order', 'type']
        : ['cloze', 'order', 'type', 'meaning', 'type', 'type'];
  return selected.map((pair, index) => {
    const hasAlignedGap = ['ca', 'pt'].every(language => Number.isInteger(pair.cloze?.[language])
      && pair.cloze[language] >= 0 && pair.cloze[language] < pair[language].split(/\s+/u).length);
    // A cloze gap must be explicitly aligned by the course author. Without that
    // annotation, both directions ask the same complete-sentence translation.
    const type = modes[index] === 'cloze' && !hasAlignedGap ? 'choose' : modes[index];
    const seed = `${level.id}:${index}`;
    const source = pair[config.source];
    const target = pair[config.target];
    const exercise = { id: `${level.id}:${index}`, type, pairId: pair.pairId, unitId: pair.unitId, source, target, answer: target,
      acceptedAnswers: acceptedSentences(pair, config.target).filter(answer => answer !== target) };
    const sameUnit = all.filter(item => item.unitId === pair.unitId);
    if (type === 'choose') exercise.options = sentenceOptions(pair, sameUnit, config.target, seed);
    if (type === 'meaning') {
      exercise.answer = source;
      exercise.acceptedAnswers = acceptedSentences(pair, config.source).filter(answer => answer !== source);
      exercise.options = sentenceOptions(pair, sameUnit, config.source, seed);
    }
    if (type === 'order') {
      const tokens = target.split(/\s+/u).map((text, tokenIndex) => ({ id: `${exercise.id}:w${tokenIndex}`, text }));
      exercise.tokens = shuffled(tokens, seed);
      if (tokens.length > 1 && exercise.tokens.every((token, tokenIndex) => token.id === tokens[tokenIndex].id)) exercise.tokens.push(exercise.tokens.shift());
    }
    if (type === 'cloze') {
      const words = target.split(/\s+/u);
      const wordIndex = pair.cloze[config.target];
      const chosen = { word: words[wordIndex], wordIndex };
      exercise.answer = trimToken(chosen.word);
      exercise.acceptedAnswers = acceptedSentences(pair, config.target).map(sentence => sentence.split(/\s+/u))
        .filter(alternative => alternative.length === words.length && alternative.every((word, wordIndex) => wordIndex === chosen.wordIndex || normalizeAnswer(word) === normalizeAnswer(words[wordIndex])))
        .map(alternative => trimToken(alternative[chosen.wordIndex])).filter(answer => answer !== exercise.answer);
      const replacement = chosen.word.replace(exercise.answer, '___');
      exercise.prompt = words.map((word, wordIndex) => wordIndex === chosen.wordIndex ? replacement : word).join(' ');
      const candidates = sameUnit.flatMap(item => item[config.target].split(/\s+/u).map(trimToken)).filter(word => word.length > 2);
      exercise.options = choiceOptions(exercise.answer, candidates, seed, exercise.acceptedAnswers);
    }
    return exercise;
  });
}

/** Case and cosmetic punctuation are forgiving; diacritics remain significant. */
export function normalizeAnswer(text) {
  return String(text ?? '').normalize('NFC').toLowerCase().replace(/[’‘ʼ`´]/gu, "'")
    .replace(/[“”«»]/gu, '"').replace(/[\u200B-\u200D\uFEFF]/gu, '')
    .trim().replace(/^[¿¡]+|[.!?…,;:]+$/gu, '').replace(/\s+/gu, ' ').trim();
}

function withoutAccents(text) {
  return text.normalize('NFD').replace(/\p{M}/gu, '').normalize('NFC');
}

export function gradeAnswer(exercise, answer) {
  const given = normalizeAnswer(Array.isArray(answer) ? answer.map(token => typeof token === 'string' ? token : token.text).join(' ') : answer);
  const allowGratitudeVariant = exercise.type !== 'cloze' || gratitudeVariant(exercise.target) !== exercise.target;
  const accepted = [exercise.answer ?? exercise.target, ...(exercise.acceptedAnswers || [])]
    .flatMap(value => allowGratitudeVariant ? [value, gratitudeVariant(value)] : [value]).map(normalizeAnswer);
  if (!given) return { correct: false, accentOnly: false };
  if (accepted.includes(given)) return { correct: true, accentOnly: false };
  if (accepted.some(expected => withoutAccents(given) === withoutAccents(expected))) return { correct: true, accentOnly: true };
  return { correct: false, accentOnly: false };
}

function validCompletion(value) {
  return value && typeof value === 'object' && Number.isFinite(value.accuracy) && value.accuracy >= PASS_ACCURACY && value.accuracy <= 1;
}

export function getCourseStats(progress) {
  const completed = progress?.completed || {};
  let completedCount = 0;
  let stars = 0;
  let nextLevel = TOTAL_LEVELS + 1;
  for (let id = 1; id <= TOTAL_LEVELS; id++) {
    if (validCompletion(completed[id])) {
      completedCount++;
      stars += Math.min(3, Math.max(1, Number(completed[id].stars) || 1));
    } else if (nextLevel === TOTAL_LEVELS + 1) nextLevel = id;
  }
  return { completedCount, nextLevel, percent: Math.round(completedCount / TOTAL_LEVELS * 100), stars, totalLevels: TOTAL_LEVELS };
}

function dateKey(now) {
  if (typeof now === 'string' && /^\d{4}-\d{2}-\d{2}(?:T|$)/u.test(now)) {
    const key = now.slice(0, 10);
    const parsed = new Date(`${key}T00:00:00Z`);
    if (!Number.isNaN(parsed.getTime()) && parsed.toISOString().slice(0, 10) === key) return key;
  }
  if (now !== undefined) throw new RangeError('Use an ISO date or timestamp');
  const date = new Date();
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
}

/** Passing is 80%; callers retain the original state for failed or locked levels. */
export function completeLevel(state, direction, levelId, score, total, nowISO) {
  directionConfig(direction);
  const id = Number(levelId);
  if (!Number.isInteger(id) || id < 1 || id > TOTAL_LEVELS) throw new RangeError('Level must be 1–300');
  if (!Number.isInteger(score) || !Number.isInteger(total) || total <= 0 || score < 0 || score > total) throw new RangeError('Invalid lesson score');
  const accuracy = score / total;
  const current = state.progress[direction];
  const stats = getCourseStats(current);
  if (accuracy < PASS_ACCURACY || id > stats.nextLevel) return state;
  const today = dateKey(nowISO);
  const old = current.completed[id];
  const stars = accuracy === 1 ? 3 : accuracy >= 0.9 ? 2 : 1;
  const earned = 20 + stars * 5;
  const oldEarned = validCompletion(old) ? (20 + Math.min(3, Math.max(1, Number(old.stars) || 1)) * 5) : 0;
  const improved = !validCompletion(old) || accuracy > old.accuracy;
  const record = improved ? { score, total, accuracy, stars, completedAt: old?.completedAt || nowISO || today, updatedAt: nowISO || today, xp: earned } : old;
  let streak = Number(state.streak) || 0;
  let lastStudyDate = state.lastStudyDate;
  if (!lastStudyDate || today > lastStudyDate) {
    const daysSince = lastStudyDate ? (Date.parse(`${today}T00:00:00Z`) - Date.parse(`${lastStudyDate}T00:00:00Z`)) / 86400000 : Infinity;
    streak = daysSince === 1 ? streak + 1 : 1;
    lastStudyDate = today;
  }
  return {
    ...state,
    xp: (Number(state.xp) || 0) + Math.max(0, earned - oldEarned),
    streak, lastStudyDate,
    progress: {
      ...state.progress,
      [direction]: { ...current, completed: { ...current.completed, [id]: record }, mistakes: [...current.mistakes] },
    },
  };
}
