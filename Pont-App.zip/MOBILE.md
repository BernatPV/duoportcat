# Pont on Android and iPhone

Pont uses the same web application, paired course content, and saved-progress format on both platforms. Its native packaging configuration uses Capacitor 8.6.2 with application ID `app.pont.languages`.

## Install the web app on a phone

First serve the contents of `dist/` from an HTTPS static host. Then open that host's app URL on your phone. The local preview server at `localhost:4173` only serves the computer running it and is not a phone-accessible hosted link. Local progress stays on that device and browser; installing or opening it in a different browser does not automatically transfer progress.

- **Android:** open the link in Chrome, open its menu, and choose **Add to Home screen** or **Install app**. The wording depends on the browser version.
- **iPhone/iPad:** open the link in Safari, tap **Share**, then **Add to Home Screen**. Enable **Open as Web App** if that option appears and tap **Add**.

Open the installed app once while online so the offline files can finish caching. Pronunciation uses the device's available speech voices. A Catalan or Portuguese voice may require a separate download in the device settings; audio is not guaranteed offline or in every browser/native webview.

This home-screen installation is a web app. It is not an App Store or Google Play release.

## What is included

- Complete app source and prebuilt `dist/` web assets.
- A self-contained `dist/Pont-Offline.html` edition that can be opened directly in a desktop browser.
- Capacitor configuration and pinned direct mobile dependencies.
- An idempotent native-project setup script.
- A manually triggered GitHub Actions workflow for an Android debug APK and an iOS Simulator app.

**No APK, signed IPA, or generated Android/iOS project is included in this package.** Native dependency installation was blocked by npm registry DNS/network access in the creation environment. Android SDK/JDK and macOS/Xcode were unavailable. The native workflow has therefore not been executed or verified here.

The prebuilt web app does not require npm dependencies. Serve `dist/` using a static web server; opening `index.html` directly with a `file://` URL will not support module loading, service workers, or installation reliably. Alternatively, open `dist/Pont-Offline.html` directly in a desktop browser for portable lessons. Its progress storage depends on the browser's local-file storage support; keep backups using the app's export option. That HTML file is not a native mobile installer, and mobile file previews may not execute it. Native setup requires internet access for npm, Gradle, Android components, and Swift packages.

## Generate native projects

Install Node.js 22 or newer. From the extracted project directory:

```sh
npm install
npm test
npm run mobile:setup -- android
```

On a Mac with Xcode 26 or newer:

```sh
npm run mobile:setup -- ios
```

The setup command builds the web assets, creates the requested native project if missing, then synchronizes web assets and applies the provided Pont launcher icons. It preserves existing native project settings except those icon references. After later edits, run `npm run mobile:sync` to update web assets in all generated native projects, or rerun setup to update icons too. Keep the generated `package-lock.json` in your repository and use `npm ci` for subsequent installations.

## Build an Android APK locally

Install Android Studio 2025.2.1 or newer and its Android SDK. The included workflow uses JDK 21, Android platform 36, and build tools 36.0.0. Android Studio includes a suitable Java runtime.

After generating `android/`, either run `npm run android` and use Android Studio's build action, or run:

```sh
# macOS / Linux
cd android
./gradlew assembleDebug
```

```powershell
# Windows PowerShell
Set-Location android
.\gradlew.bat assembleDebug
```

The debug-signed APK is written to `android/app/build/outputs/apk/debug/app-debug.apk`. Copy it to an Android phone and open it to install, following Android's install permission prompt for the app that opened the file. A debug APK is for testing; use a separately managed release signing key and release build for distribution or Google Play. Do not commit signing keys or passwords.

## Build using the included workflow

1. Put this project's contents at the root of a GitHub repository, including `.github/workflows/mobile-builds.yml`.
2. Open **Actions then Build mobile test apps then Run workflow** and select a platform.
3. After a successful run, download the generated artifact from that run.

The Android artifact contains an installable debug APK. **The iOS artifact runs only in the Xcode Simulator on a Mac; it cannot be installed on an iPhone.** GitHub account availability, runner access, and usage charges depend on your account. The workflow does not publish to an app store or use signing credentials.

## Install a native build on an iPhone

Generate the iOS project on a Mac and run `npm run ios` to open Xcode. Select a connected iPhone and your Apple development team in **Signing & Capabilities**, resolve the bundle identifier if it conflicts with an existing app, and run the app. Device signing/provisioning is required.

For a reusable downloadable release, configure your Apple Developer team, archive a release build in Xcode, and distribute through TestFlight or the App Store. A signed IPA must be built for an authorized distribution method; a generic unsigned IPA cannot be installed on arbitrary iPhones. This package does not include an Apple account, provisioning profile, signing certificate, store listing, or store approval.

Before store submission, set your final bundle identifiers, review the generated app icons on real devices, test both directions and audio, and prepare the required store privacy and listing information.

## Official references

- [Capacitor installation](https://capacitorjs.com/docs/getting-started)
- [Capacitor environment requirements](https://capacitorjs.com/docs/getting-started/environment-setup)
- [Capacitor Android requirements and minimum SDK](https://capacitorjs.com/docs/updating/8-0)
- [Capacitor iOS distribution](https://capacitorjs.com/docs/ios/deploying-to-app-store)
- [GitHub-hosted runners](https://docs.github.com/en/actions/reference/runners/github-hosted-runners)
