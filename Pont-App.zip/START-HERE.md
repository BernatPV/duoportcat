# Start learning with Pont

1. Extract the ZIP download.
2. Open **`dist/Pont-Offline.html`** in a modern desktop browser. If necessary, right-click it, choose **Open with**, and select your browser.
3. Choose **Portuguese from Catalan** or **Catalan from Portuguese**, then start level 1.

This portable file contains the complete app and course. Lessons do not need an internet connection or software installation. Progress depends on the browser allowing local storage for local files; use the same browser and file location and export a backup from the app's settings. Moving the file, private browsing, or clearing browser data may make progress unavailable.

## What you can learn

- 300 levels across 30 units, with 600 bilingual sentence pairs.
- The same course and exercises in both directions, with the languages swapped.
- Translation choices, meaning questions, sentence ordering, and typed translations.
- Increasing difficulty, cumulative review, mistake practice, vocabulary collection, XP, and streaks.
- Separate saved progress for each direction, with export and import.
- Pronunciation when a suitable Portuguese or Catalan voice is available on the device. Audio may need a connection.

The course uses European Portuguese and standard Catalan. Each level contains six exercises; five correct answers unlock the next level.

## Use it on Android or iPhone

The portable HTML file is not a mobile installer. To install the web app on a phone, first host all files in `dist/` on an HTTPS static host, then open the resulting app URL:

- **Android / Chrome:** choose **Install app** or **Add to Home screen** from the browser menu.
- **iPhone / Safari:** choose **Share**, then **Add to Home Screen**. Enable **Open as Web App** if offered.

Open the installed app online once and allow its course files to cache before studying offline. The included local preview server runs only on your computer; its localhost URL is not a phone download link.

## Native download status

**This package does not contain an Android APK or an iPhone IPA.** Native builds could not run in the creation environment: npm could not resolve `registry.npmjs.org`, the Android SDK and Java/JDK were unavailable, and the Windows host has no macOS/Xcode toolchain. iPhone device distribution also requires Apple signing and provisioning.

The package includes Capacitor configuration, native-project setup scripts, and an optional GitHub Actions workflow for an Android debug APK and an iOS Simulator app. The workflow has not been run here; its iOS output is for a Mac simulator, not an iPhone. See [MOBILE.md](MOBILE.md) for native build and signing steps, and [README.md](README.md) for source editing and the local web server.
