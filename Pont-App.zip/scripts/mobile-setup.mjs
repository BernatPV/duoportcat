import { existsSync, mkdirSync, copyFileSync, readFileSync, writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { resolve, dirname } from 'node:path';
import { spawnSync } from 'node:child_process';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const platforms = process.argv.slice(2);
if (!platforms.length || platforms.some(p => !['android', 'ios'].includes(p))) {
  console.error('Usage: npm run mobile:setup -- android [ios]');
  process.exit(1);
}
if (!existsSync(resolve(root, 'dist/index.html'))) {
  console.error('Missing dist/index.html. Run npm run build first.');
  process.exit(1);
}
const cli = resolve(root, 'node_modules/@capacitor/cli/bin/capacitor');
if (!existsSync(cli)) {
  console.error('Capacitor is not installed. Run npm install with internet access first.');
  process.exit(1);
}
function cap(...args) {
  const result = spawnSync(process.execPath, [cli, ...args], {
    cwd: root,
    stdio: 'inherit',
    env: { ...process.env, CI: process.env.CI || 'true' },
  });
  if (result.error) throw result.error;
  if (result.status !== 0) process.exit(result.status || 1);
}
function copyIcons(platform) {
  if (platform === 'ios') {
    const icon = resolve(root, 'dist/icons/icon-1024.png');
    const target = resolve(root, 'ios/App/App/Assets.xcassets/AppIcon.appiconset');
    if (existsSync(icon) && existsSync(target)) {
      copyFileSync(icon, resolve(target, 'AppIcon-1024.png'));
      writeFileSync(resolve(target, 'Contents.json'), JSON.stringify({
        images: [{ filename: 'AppIcon-1024.png', idiom: 'universal', platform: 'ios', size: '1024x1024' }],
        info: { author: 'xcode', version: 1 },
      }, null, 2));
    }
  } else {
    const icon = resolve(root, 'dist/icons/icon-512.png');
    const target = resolve(root, 'android/app/src/main/res/mipmap-nodpi');
    const manifest = resolve(root, 'android/app/src/main/AndroidManifest.xml');
    if (existsSync(icon) && existsSync(manifest)) {
      mkdirSync(target, { recursive: true });
      copyFileSync(icon, resolve(target, 'pont_icon.png'));
      const xml = readFileSync(manifest, 'utf8')
        .replace('android:icon="@mipmap/ic_launcher"', 'android:icon="@mipmap/pont_icon"')
        .replace('android:roundIcon="@mipmap/ic_launcher_round"', 'android:roundIcon="@mipmap/pont_icon"');
      writeFileSync(manifest, xml);
    }
  }
}
for (const platform of [...new Set(platforms)]) {
  if (platform === 'ios' && process.platform !== 'darwin') {
    console.error('iOS setup requires macOS with Xcode 26 or later. Use the included macOS CI job instead.');
    process.exit(1);
  }
  if (!existsSync(resolve(root, platform))) cap('add', platform);
  cap('sync', platform);
  copyIcons(platform);
}
console.log('Native projects are ready. See MOBILE.md for build and signing steps.');
