import {mkdir,cp,readFile,writeFile} from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';
const root=path.resolve(import.meta.dirname,'..');
const course=(await Promise.all(['01-10','11-20','21-30'].map(async part=>JSON.parse(await readFile(path.join(root,`content/units-${part}.json`),'utf8'))))).flat();
if(course.length!==30 || course.some((u,i)=>u.id!==i+1||u.pairs.length!==20||!u.pairs.every(p=>p.ca&&p.pt))) throw new Error('Expected 30 ordered units with 20 bilingual pairs each');
await mkdir(path.join(root,'dist'),{recursive:true});
await cp(path.join(root,'src'),path.join(root,'dist'),{recursive:true});
await writeFile(path.join(root,'dist/course.json'),JSON.stringify(course));
// A changed course or app must get a fresh offline cache on the next install.
const cacheHash=createHash('sha256');
for(const file of ['app.js','engine.js','styles.css','course.json','index.html']) cacheHash.update(await readFile(path.join(root,'dist',file)));
const sw=await readFile(path.join(root,'src/sw.js'),'utf8');
await writeFile(path.join(root,'dist/sw.js'),sw.replace(/const CACHE='[^']+';/,`const CACHE='pont-${cacheHash.digest('hex').slice(0,16)}';`));
// A portable, completely self-contained edition also works without a web server.
let html=await readFile(path.join(root,'src/index.html'),'utf8');
const css=(await readFile(path.join(root,'src/styles.css'),'utf8')).replace(/@import[^;]+;/g,'');
const logo='data:image/svg+xml;base64,'+Buffer.from(await readFile(path.join(root,'src/icon.svg'))).toString('base64');
const engine=(await readFile(path.join(root,'src/engine.js'),'utf8')).replace(/^export default .*;$/gm,'').replace(/^export /gm,'');
const app=(await readFile(path.join(root,'src/app.js'),'utf8')).replace(/^import .*;\r?\n/,'').replace("await fetch('./course.json')",`({ok:true,json:async()=>${JSON.stringify(course)}})`).replaceAll('./icon.svg',logo);
html=html.replace(/<link[^>]+(?:manifest|icon)[^>]*>/g,'').replace('<link rel="stylesheet" href="./styles.css">',`<style>${css}</style>`).replace('<script type="module" src="./app.js"></script>',`<script type="module">${engine}\n${app}</script>`);
await writeFile(path.join(root,'dist/Pont-Offline.html'),html);
console.log(`Built Pont: ${course.length} units, 300 levels, ${course.reduce((n,u)=>n+u.pairs.length,0)} bilingual pairs.`);
